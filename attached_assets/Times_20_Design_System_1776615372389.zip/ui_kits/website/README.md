# Times 20 Website UI Kit

## Overview
A click-through prototype of the Times 20 Consulting marketing website. Five pages: Home, Services, Work, About, Contact.

## Pages
- **Home** — Hero, stat bar, services overview, CTA
- **Services** — 6 service cards grid
- **Work** — Case study cards with results
- **About** — Mission statement + 20× callout
- **Contact** — Working form with validation + success state

## Components
- `Nav` — Sticky nav with scroll-shadow effect
- `Footer` — Dark footer with nav links
- `HomePage`, `ServicesPage`, `WorkPage`, `AboutPage`, `ContactPage`

## Design Notes
- Fonts: Barlow Condensed (display), Barlow (headings), DM Sans (body/UI)
- Icons: Lucide via CDN
- Colors: from `colors_and_type.css` (vars inlined)
- All state persisted via `localStorage` (page position survives refresh)
