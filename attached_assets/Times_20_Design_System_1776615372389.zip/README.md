# Times 20 (X20) Design System

## Company Overview

**Times 20 Consulting** is a force-multiplier agency that helps clients solve CRM problems and monetize their audiences. They work primarily with:

1. **Content Creators** — Building systems to monetize audiences (CRM, pipelines, automation)
2. **Business Clients** — CRM implementation + content strategy to produce better content faster and at higher volume

The brand name "Times 20" (stylized as **X20**) is a direct statement of their value proposition: they make their clients 20× more effective.

**Sources provided:**
- `uploads/x20 blue logo.svg` — Primary brand logo (SVG vector)
- CSS color variables (provided inline, no codebase attached)
- No Figma link provided
- No production codebase attached

---

## CONTENT FUNDAMENTALS

**Tone:** Confident, direct, results-oriented. This is a performance agency — every word should feel like it earns its place. No fluff, no filler.

**Voice:** We/You — the agency speaks as a partner ("We help you…", "Your audience…"). Positions the client as the protagonist, X20 as the enabler.

**Casing:** Title Case for headlines and CTAs. Sentence case for body copy. ALL CAPS used sparingly for labels, category tags, and overlines.

**Sentence style:** Short, punchy sentences in headlines. Longer, explanatory prose only in body. No em-dash abuse.

**Emoji:** Not used. The brand is professional and systems-focused; emoji would undercut authority.

**Numbers:** Written as numerals (20×, 3 systems, $1M). The "×" (multiply) symbol is core to the brand identity.

**Key phrases / vocabulary:**
- "Force multiplier" — core positioning
- "Monetize your audience"
- "Build systems"
- "CRM" — spoken plainly, not jargon-buried
- "Content velocity" — volume + quality
- "At scale"

**Example headlines:**
- "We build the systems that turn audiences into revenue."
- "CRM that works the way you do."
- "More content. Better content. Faster."

---

## VISUAL FOUNDATIONS

### Colors
Primary palette is **deep navy blue** anchored in trust, authority, and precision. The mid-blue (`#62a8db`) comes directly from the logo and adds energy without sacrificing seriousness.

- **Primary:** `#0b3b92` — confident, institutional blue; used for CTAs, key UI elements
- **Navy (logo X):** `#002b7a` — deepest brand anchor; used for text-on-light overlays, heavy emphasis
- **Mid Blue:** `#62a8db` — logo background; accent, highlight states
- **Light Blue:** `#a9c4e4` — borders, icon strokes, disabled states
- **Soft Blue:** `#dce7f4` — page backgrounds, input fills, card tints
- **White:** `#ffffff` — primary surface

No warm accents. No gradients in core UI. Color says: *systematic, trustworthy, performance-focused.*

### Typography
- **Display / Headlines:** Barlow Condensed — tall, compressed, authoritative. Used for hero text, section titles, stat callouts.
- **Body / UI:** DM Sans — clean, legible, neutral. Used for all paragraph copy, labels, UI controls.
- **No serif.** The brand is modern and systems-oriented — serifs would read as old-fashioned consulting.

Heading hierarchy is tightly controlled: large type is BIG (52px+), body is consistently 16px. Strong contrast between display and body sizes.

### Spacing & Layout
- 8px base grid. All spacing is multiples of 4/8px.
- Layouts are structured and grid-aligned — no organic, free-form placement.
- Generous whitespace — never cramped.
- Fixed-width containers (max ~1200px) centered on wide screens.

### Backgrounds
- Primary: white (`#ffffff`) with soft blue (`#dce7f4`) for alternating sections.
- Dark sections use `#06265d` (x20-blue-darker) for contrast panels.
- No textures, no gradients, no photography backgrounds. Clean, minimal, system-focused.

### Cards
- Background: white. Border: 1px `#c8d9ee`. Radius: 6–10px.
- Shadow: subtle blue-tinted drop shadow (`--shadow-md`).
- On hover: shadow deepens, slight lift (`translateY(-2px)`).

### Borders
- 1px solid `var(--x20-border)` (`#c8d9ee`) for standard dividers.
- Blue-soft fills for subtle containment.
- No colored left-border accent cards.

### Shadows
- Blue-tinted shadows only (no black/gray). Shadow color keyed to `rgba(11,59,146,…)`.
- Three levels: sm (lists/inputs), md (cards), lg (modals/popovers).

### Animation
- **Easing:** `ease` for most transitions. No bounces or spring physics.
- **Speed:** 150ms (micro), 220ms (standard), 380ms (page transitions).
- Hover: shadow + slight lift. Press: `scale(0.97)`. No color flashes.
- No decorative animation. Motion is functional only.

### Iconography
See ICONOGRAPHY section below.

### Corner Radii
- Small UI elements (tags, inputs): 3–6px
- Cards, panels: 6–10px
- Pills (badges, chips): 999px
- No fully rounded buttons; subtle radius only.

### Imagery
- No photography or illustration in core brand materials (none provided).
- If imagery is added: cool-toned, clean, professional.

---

## ICONOGRAPHY

**Approach:** Stroke-based icons, single weight. No filled icons except in specific active/selected states. The brand's precision positioning calls for clean, unambiguous iconography — no decorative or illustrative icons.

**Recommended system:** [Lucide Icons](https://lucide.dev/) — available via CDN. Matches the brand's clean, minimal aesthetic.

```html
<!-- Lucide via CDN -->
<script src="https://unpkg.com/lucide@latest/dist/umd/lucide.min.js"></script>
```

**Usage rules:**
- Stroke weight: 1.5px (Lucide default)
- Size: 16px (inline), 20px (UI controls), 24px (section callouts)
- Color: inherits text color or uses `--x20-blue` for emphasis
- No emoji used as icons
- No unicode chars as icons

**Assets:**
- `assets/x20-blue-logo.svg` — Primary logo (X20 mark on blue background)

---

## FILE INDEX

```
/
├── README.md                  ← This file
├── SKILL.md                   ← Agent skill definition
├── colors_and_type.css        ← All CSS vars (colors, type, spacing, shadow, radius)
├── assets/
│   └── x20-blue-logo.svg      ← Primary brand logo
├── preview/                   ← Design system cards (registered in asset viewer)
│   ├── colors-brand.html
│   ├── colors-neutral.html
│   ├── colors-semantic.html
│   ├── type-scale.html
│   ├── type-specimens.html
│   ├── spacing-tokens.html
│   ├── shadow-radius.html
│   ├── components-buttons.html
│   ├── components-badges.html
│   ├── components-cards.html
│   ├── components-inputs.html
│   └── brand-logo.html
└── ui_kits/
    └── website/
        ├── README.md
        └── index.html         ← Times 20 agency website prototype
```
